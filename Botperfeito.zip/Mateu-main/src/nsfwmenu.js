const nsfwmenu = (prefix, pushname) => {
    return `Oiin resumindo aqui e o menu NSFW
    ◪ *NSFW*
  │
  ├─ ❏ ${prefix}nsfwbobs
  ├─ ❏ ${prefix}randomhentaio
  ├─ ❏ ${prefix}nsfwtrap
  ├─ ❏ ${prefix}nsfwass
  ├─ ❏ ${prefix}nsfwbelly
  ├─ ❏ ${prefix}nsfwsidebobs
  ├─ ❏ ${prefix}nsfwahegao
  ├─ ❏ ${prefix}nsfwthighs
  ├─ ❏ ${prefix}nsfwarmpits
  └─ ❏ ${prefix}nsfwfeets

  _obs para usar esses comandos ative o menu NSFW_\n _Digite_\n ${prefix}*nsfw 1*`



}

exports.nsfwmenu = nsfwmenu