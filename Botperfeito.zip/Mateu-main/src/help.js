const help = (prefix, pushname, botname, oname) => {
	return `
  「 *BOT* 」
࿇ ══━━━━✥◈✥━━━━══ ࿇
  
  ◪ *INFORMAÇÕES*
    ❏ Prefix: 「  ${prefix}  」
    ❏ Criador: *🔥mateu🔥*
    ❏ Numero do meu criador: WA.me/+1(579)9968046
 ࿇ ══━━━━✥◈✥━━━━══ ࿇
    Outros Menus
    ❏${prefix}nsfwmenu
    ❏${prefix}menuadmin
  
    
  ◪ *LEVEL*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}leveling
    └─ ❏ ${prefix}level
  ◪ *CRIAR*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}sticker
    ├─ ❏ ${prefix}toimg
    ├─ ❏ ${prefix}bpink
    ├─ ❏ ${prefix}marvellogo
    ├─ ❏ ${prefix}snowwrite
    ├─ ❏ ${prefix}3dtext
    ├─ ❏ ${prefix}ninjalogo
    ├─ ❏ ${prefix}water
    ├─ ❏ ${prefix}firetext
    ├─ ❏ ${prefix}neonlogo
    ├─ ❏ ${prefix}lionlogo
    ├─ ❏ ${prefix}jokerlogo
    └─ ❏ ${prefix}quotemaker
  ◪ *PESQUISA*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}wiki
    ├─ ❏ ${prefix}wikien
    ├─ ❏ ${prefix}nulis
    └─ ❏ ${prefix}artinama
  ◪ *DOWNLOADER*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}images 
    ├─ ❏ ${prefix}ytmp3
    ├─ ❏ ${prefix}ytmp4
    ├─ ❏ ${prefix}joox
    ├─ ❏ ${prefix}joox2
    ├─ ❏ ${prefix}trendtwit
    └─ ❏ ${prefix}ytsearch
  ◪ *MEME*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}meme
    └─ ❏ ${prefix}memeindo
  ◪ *SOM*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}play
    └─ ❏ ${prefix}tts
  ◪ *MUSICA*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}lirik
    └─ ❏ ${prefix}chord
  ◪ *STALKEAR*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}tiktokstalk
    └─ ❏ ${prefix}igstalk
  ◪ *WIBU*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}neonime
    ├─ ❏ ${prefix}pokemon
    ├─ ❏ ${prefix}loli
    ├─ ❏ ${prefix}waifu
    ├─ ❏ ${prefix}wallpaper
    ├─ ❏ ${prefix}neko
    └─ ❏ ${prefix}nekonime
  ◪ *DIVERSÃO*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}alay
    ├─ ❏ ${prefix}gantengcek
    ├─ ❏ ${prefix}watak
    ├─ ❏ ${prefix}hobby
    ├─ ❏ ${prefix}game
    ├─ ❏ ${prefix}simih
    └─ ❏ ${prefix}glitch
  ◪ *INFORMAÇÂO*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}bahasa
    ├─ ❏ ${prefix}kodenegara
    ├─ ❏ ${prefix}kbbi
    ├─ ❏ ${prefix}fakta
    ├─ ❏ ${prefix}infocuaca
    └─ ❏ ${prefix}covid
  ◪ *OUTROS*
  ࿇ ══━━━━✥◈✥━━━━══ ࿇
    │
    ├─ ❏ ${prefix}send
    ├─ ❏ ${prefix}wame
    ├─ ❏ ${prefix}virtex
    ├─ ❏ ${prefix}exe
    ├─ ❏ ${prefix}qrcode
    ├─ ❏ ${prefix}quotes
    └─ ❏ ${prefix}fml
  `
}

exports.help = help