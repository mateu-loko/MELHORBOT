const bruxinhomenu = (prefix, pushname) => {
    return `◪ *Comandos do mateu*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.bruxinhomenu = bruxinho