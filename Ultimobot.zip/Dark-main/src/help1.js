const help1 = (prefix) => {

	return `
╭──────────────╮
 *COMANDOS*
╰──────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}loli*
➸ *${prefix}nsfw 1
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}hentai2
➸ *${prefix}neko*
➸ *${prefix}meme*
➸ *${prefix}lolihentai
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}ts (texto que deseja transmitir)*

════════════════════
*Digite ${prefix}dono para mais info*
════════════════════`

}
exports.help1 = help1

